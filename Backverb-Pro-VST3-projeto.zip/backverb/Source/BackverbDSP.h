// Backverb Pro - DSP (sem dependencias de JUCE, so C++ padrao)
#pragma once
#include <vector>
#include <cmath>
#include <algorithm>

namespace bv
{
constexpr double kPi = 3.14159265358979323846;

struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;

    float process (float x)
    {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void reset() { z1 = z2 = 0; }

    void set (double nb0, double nb1, double nb2, double na0, double na1, double na2)
    {
        b0 = (float) (nb0 / na0); b1 = (float) (nb1 / na0); b2 = (float) (nb2 / na0);
        a1 = (float) (na1 / na0); a2 = (float) (na2 / na0);
    }
    void setHighPass (double fs, double f)
    {
        const double w = 2 * kPi * f / fs, c = std::cos (w), al = std::sin (w) / (2 * 0.7071);
        set ((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
    }
    void setLowShelf (double fs, double f, double gainDb)
    {
        const double A = std::pow (10.0, gainDb / 40), w = 2 * kPi * f / fs, c = std::cos (w);
        const double al = std::sin (w) / 2 * std::sqrt (2.0), s = 2 * std::sqrt (A) * al;
        set (A * ((A + 1) - (A - 1) * c + s), 2 * A * ((A - 1) - (A + 1) * c), A * ((A + 1) - (A - 1) * c - s),
             (A + 1) + (A - 1) * c + s, -2 * ((A - 1) + (A + 1) * c), (A + 1) + (A - 1) * c - s);
    }
    void setHighShelf (double fs, double f, double gainDb)
    {
        const double A = std::pow (10.0, gainDb / 40), w = 2 * kPi * f / fs, c = std::cos (w);
        const double al = std::sin (w) / 2 * std::sqrt (2.0), s = 2 * std::sqrt (A) * al;
        set (A * ((A + 1) + (A - 1) * c + s), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - s),
             (A + 1) - (A - 1) * c + s, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - s);
    }
};

// Reverb estereo estilo Freeverb
class Reverb
{
public:
    void prepare (double sr)
    {
        static const int ct[8] = { 1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617 };
        static const int at[4] = { 556, 441, 341, 225 };
        const double k = sr / 44100.0;
        for (int c = 0; c < 2; ++c)
        {
            const int spread = c * 23;
            for (int i = 0; i < 8; ++i) combs[c][i].init ((int) ((ct[i] + spread) * k) + 1);
            for (int i = 0; i < 4; ++i) aps[c][i].init ((int) ((at[i] + spread) * k) + 1);
        }
    }
    void reset() { for (int c = 0; c < 2; ++c) { for (auto& x : combs[c]) x.clear(); for (auto& x : aps[c]) x.clear(); } }

    void process (float inL, float inR, float fb, float damp, float& outL, float& outR)
    {
        const float in = (inL + inR) * 0.5f * 0.03f;
        float o[2];
        for (int c = 0; c < 2; ++c)
        {
            float s = 0;
            for (int i = 0; i < 8; ++i) s += combs[c][i].process (in, fb, damp);
            for (int i = 0; i < 4; ++i) s = aps[c][i].process (s);
            o[c] = s;
        }
        outL = o[0]; outR = o[1];
    }

private:
    struct Comb
    {
        std::vector<float> buf; int idx = 0; float store = 0;
        void init (int n) { buf.assign ((size_t) n, 0.f); idx = 0; store = 0; }
        void clear() { std::fill (buf.begin(), buf.end(), 0.f); idx = 0; store = 0; }
        float process (float in, float fb, float damp)
        {
            const float out = buf[(size_t) idx];
            store = out * (1 - damp) + store * damp;
            buf[(size_t) idx] = in + store * fb;
            if (++idx >= (int) buf.size()) idx = 0;
            return out;
        }
    };
    struct Allpass
    {
        std::vector<float> buf; int idx = 0;
        void init (int n) { buf.assign ((size_t) n, 0.f); idx = 0; }
        void clear() { std::fill (buf.begin(), buf.end(), 0.f); idx = 0; }
        float process (float in)
        {
            const float b = buf[(size_t) idx];
            const float out = -in + b;
            buf[(size_t) idx] = in + b * 0.5f;
            if (++idx >= (int) buf.size()) idx = 0;
            return out;
        }
    };
    Comb combs[2][8];
    Allpass aps[2][4];
};

struct Params
{
    int   length = 2;        // 0..3 = 1/4 bar, 1/2 bar, 1 bar, 2 bars
    float shape = 65;        // %
    float ducking = 40;      // %
    float size = 50;         // %
    float tone = 50;         // %
    float width = 1;         // 0..2
    float tremolo = 0;       // %
    int   tremSpeed = 1;     // 0..2 = 1/4, 1/8, 1/16
    bool  lowCut = false;
    float mix = 50;          // %
    float outGainDb = 0;     // -24..12
};

class Backverb
{
public:
    void prepare (double sampleRate)
    {
        sr = sampleRate;
        cap = (int) (sr * 13.0);
        for (int b = 0; b < 2; ++b) for (int c = 0; c < 2; ++c) buf[b][c].assign ((size_t) cap, 0.f);
        reverb.prepare (sr);
        envAtt = 1.0f - std::exp (-1.0f / (0.005f * (float) sr));
        envRel = 1.0f - std::exp (-1.0f / (0.150f * (float) sr));
        reset();
    }

    void reset()
    {
        reverb.reset();
        for (int c = 0; c < 2; ++c) { lo[c].reset(); hi[c].reset(); hp[c].reset(); }
        recIdx = 0; playIdx = 1; writePos = 0; playLen = 0; playPos = 0;
        env = 0; trem = 0; lastSync = false; lastSeg = 0;
    }

    // bpm <= 0 => desconhecido (usa 120). havePpq => host esta tocando e deu a posicao em beats.
    void process (float* L, float* R, int n, const Params& p, double bpm, double ppq, bool havePpq)
    {
        if (! (bpm > 20)) bpm = 120;
        bpm = std::min (300.0, std::max (40.0, bpm));
        static const double kBeats[4] = { 1, 2, 4, 8 };
        const double beats = kBeats[std::min (3, std::max (0, p.length))];
        const int segLen = std::min (cap, std::max (1024, (int) (beats * 60.0 / bpm * sr)));

        const float fb   = 0.7f + 0.26f * std::min (0.98f, std::max (0.05f, p.size * 0.01f));
        const float damp = 0.2f + 0.5f * (1.0f - p.tone * 0.01f);
        const float tilt = (p.tone - 50.0f) * 0.24f;
        for (int c = 0; c < 2; ++c)
        {
            lo[c].setLowShelf (sr, 600.0, -tilt);
            hi[c].setHighShelf (sr, 3000.0, tilt);
            hp[c].setHighPass (sr, 180.0);
        }
        const float exponent = 1.0f + 3.0f * std::min (1.0f, std::max (0.0f, p.shape * 0.01f));
        const float duck = std::min (1.0f, std::max (0.0f, p.ducking * 0.01f));
        const float tremDepth = std::min (1.0f, std::max (0.0f, p.tremolo * 0.01f));
        static const double kTrem[3] = { 1, 2, 4 };
        const double tremInc = 2 * kPi * (bpm / 60.0) * kTrem[std::min (2, std::max (0, p.tremSpeed))] / sr;
        const float mix = std::min (1.0f, std::max (0.0f, p.mix * 0.01f));
        const float outG = std::pow (10.0f, p.outGainDb / 20.0f);
        const int fade = std::max (1, (int) (sr * 0.004));

        if (havePpq != lastSync)
        {
            lastSync = havePpq;
            writePos = 0;
            lastSeg = (long long) std::floor (ppq / beats);
        }
        const double dppq = bpm / 60.0 / sr;
        double ppqCur = ppq;

        for (int i = 0; i < n; ++i)
        {
            const float dryL = L[i], dryR = R[i];

            if (havePpq)
            {
                const long long seg = (long long) std::floor (ppqCur / beats);
                if (seg != lastSeg) { boundary(); lastSeg = seg; }
                ppqCur += dppq;
            }
            else if (writePos >= segLen)
                boundary();

            // envelope do sinal de entrada (para o ducking)
            const float e = std::max (std::fabs (dryL), std::fabs (dryR));
            env += (e - env) * (e > env ? envAtt : envRel);

            // reverb continuo -> gravado no buffer
            float wl, wr;
            reverb.process (dryL, dryR, fb, damp, wl, wr);
            if (writePos < cap)
            {
                buf[recIdx][0][(size_t) writePos] = wl;
                buf[recIdx][1][(size_t) writePos] = wr;
                ++writePos;
            }

            // reproduz o trecho anterior ao contrario, com a curva "Shape"
            float pl = 0, pr = 0;
            if (playPos < playLen)
            {
                const int idx = playLen - 1 - playPos;
                float g = std::pow ((float) playPos / (float) playLen, exponent);
                const int rem = playLen - playPos;
                if (rem < fade) g *= (float) rem / (float) fade;
                pl = buf[playIdx][0][(size_t) idx] * g;
                pr = buf[playIdx][1][(size_t) idx] * g;
                ++playPos;
            }

            // tremolo (sincronizado ao tempo)
            const float tg = 1.0f - tremDepth * (0.5f + 0.5f * (float) std::sin (trem));
            trem += tremInc; if (trem > 2 * kPi) trem -= 2 * kPi;
            pl *= tg; pr *= tg;

            // ducking
            const float dg = 1.0f - duck * std::min (1.0f, env * 3.0f);
            pl *= dg; pr *= dg;

            // tom (tilt) e low cut
            pl = hi[0].process (lo[0].process (pl));
            pr = hi[1].process (lo[1].process (pr));
            if (p.lowCut) { pl = hp[0].process (pl); pr = hp[1].process (pr); }

            // largura
            const float m = (pl + pr) * 0.5f, s = (pl - pr) * 0.5f * p.width;
            pl = m + s; pr = m - s;

            L[i] = (dryL * (1.0f - mix * 0.5f) + pl * mix * 3.0f) * outG;
            R[i] = (dryR * (1.0f - mix * 0.5f) + pr * mix * 3.0f) * outG;
        }
    }

private:
    void boundary()
    {
        playIdx = recIdx;
        recIdx ^= 1;
        playLen = std::min (writePos, cap);
        playPos = 0;
        writePos = 0;
    }

    double sr = 44100;
    int cap = 0;
    std::vector<float> buf[2][2];
    int recIdx = 0, playIdx = 1, writePos = 0, playLen = 0, playPos = 0;
    float env = 0, envAtt = 0, envRel = 0;
    double trem = 0;
    bool lastSync = false;
    long long lastSeg = 0;
    Reverb reverb;
    Biquad lo[2], hi[2], hp[2];
};
} // namespace bv
