#include "PluginProcessor.h"

using APF = juce::AudioParameterFloat;
using APC = juce::AudioParameterChoice;
using APB = juce::AudioParameterBool;
using PID = juce::ParameterID;

juce::AudioProcessorValueTreeState::ParameterLayout BackverbAudioProcessor::createLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (std::make_unique<APC> (PID { "length", 1 }, "Length",
                 juce::StringArray { "1/4 Bar", "1/2 Bar", "1 Bar", "2 Bars" }, 2));

    auto pct = [] (const char* id, const char* name, float def)
    {
        return std::make_unique<APF> (PID { id, 1 }, name,
                                      juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), def,
                                      juce::AudioParameterFloatAttributes().withLabel ("%"));
    };
    p.push_back (pct ("shape",   "Shape",   65.0f));
    p.push_back (pct ("ducking", "Ducking", 40.0f));
    p.push_back (pct ("size",    "Size",    50.0f));
    p.push_back (pct ("tone",    "Tone",    50.0f));

    p.push_back (std::make_unique<APF> (PID { "width", 1 }, "Width",
                 juce::NormalisableRange<float> (0.0f, 2.0f, 0.01f), 1.0f));

    p.push_back (pct ("tremolo", "Tremolo", 0.0f));
    p.push_back (std::make_unique<APC> (PID { "tremspeed", 1 }, "Tremolo Speed",
                 juce::StringArray { "1/4", "1/8", "1/16" }, 1));
    p.push_back (std::make_unique<APB> (PID { "lowcut", 1 }, "Low Cut", false));
    p.push_back (pct ("mix", "Mix", 50.0f));

    p.push_back (std::make_unique<APF> (PID { "output", 1 }, "Output",
                 juce::NormalisableRange<float> (-24.0f, 12.0f, 0.1f), 0.0f,
                 juce::AudioParameterFloatAttributes().withLabel ("dB")));

    return { p.begin(), p.end() };
}

BackverbAudioProcessor::BackverbAudioProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
}

void BackverbAudioProcessor::prepareToPlay (double sampleRate, int)
{
    dsp.prepare (sampleRate);
}

bool BackverbAudioProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    return l.getMainInputChannelSet() == juce::AudioChannelSet::stereo()
        && l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void BackverbAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    bv::Params p;
    p.length    = (int) get ("length");
    p.shape     = get ("shape");
    p.ducking   = get ("ducking");
    p.size      = get ("size");
    p.tone      = get ("tone");
    p.width     = get ("width");
    p.tremolo   = get ("tremolo");
    p.tremSpeed = (int) get ("tremspeed");
    p.lowCut    = get ("lowcut") > 0.5f;
    p.mix       = get ("mix");
    p.outGainDb = get ("output");

    double bpm = 120.0, ppq = 0.0;
    bool havePpq = false;
    if (auto* ph = getPlayHead())
    {
        if (auto pos = ph->getPosition())
        {
            if (auto b = pos->getBpm()) bpm = *b;
            if (pos->getIsPlaying())
                if (auto q = pos->getPpqPosition()) { ppq = *q; havePpq = true; }
        }
    }

    const int n = buffer.getNumSamples();
    if (buffer.getNumChannels() < 2) return;
    dsp.process (buffer.getWritePointer (0), buffer.getWritePointer (1), n, p, bpm, ppq, havePpq);
}

juce::AudioProcessorEditor* BackverbAudioProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);
}

void BackverbAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void BackverbAudioProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new BackverbAudioProcessor();
}
